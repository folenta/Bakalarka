#! /usr/bin/env python
# -*- coding: utf-8 -*-

from __future__ import division, print_function, absolute_import

import os
import random
from math import atan
from timeit import time
import warnings
import sys
import math
from math import sin, cos
import cv2
import numpy as np
from PIL import Image
from yolo import YOLO
from shapely.geometry import Point
from shapely.geometry.polygon import Polygon
from shapely.ops import nearest_points

"""from numpy import array
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM
from tensorflow.keras.layers import Dense"""

from deep_sort import preprocessing
from deep_sort import nn_matching
from deep_sort.detection import Detection
from deep_sort.tracker import Tracker
from tools import generate_detections as gdet
from deep_sort.detection import Detection as ddet
from trajectory import Trajectory
from clustering import Clustering

warnings.filterwarnings('ignore')


def list2trajectories(trajs):
    result = []
    for traj in trajs:
        t = Trajectory(-1)
        for p in traj:
            p = p.split(',')
            x = p[0][1:]
            y = p[1][:-1]
            t.addPoint((int(x), int(y)))
        result.append(t)
    return result


def draw_analyze(frame):
    cv2.imwrite("frame.jpg", frame)


def get_coord_from_str(coord):
    coord = coord.split(',')
    x = coord[0]
    y = coord[1]

    return int(x), int(y)


def check_empty_point(points):
    if points[0] == ' ':
        points = points[1:]

    return points


def get_coordinates(point):
    x = point[0]
    y = point[1]

    return float(x), float(y)


def find_start_area(point, starts):
    idx = 0
    for start in starts:
        idx += 1
        if start.contains(point):
            return idx

    return "-"


def find_nearest_start_area(point, starts):
    if isinstance(point, list):
        x, y = get_coordinates(point)
        point = Point(int(x), int(y))
    distance_vector = []

    for area in range(0, len(starts)):
        distance = starts[area].exterior.distance(point)
        distance_vector.append(distance)

    sorted_distance = sorted(range(len(distance_vector)), key=lambda k: distance_vector[k])
    return sorted_distance


def find_start(points, starts, roi):
    # points = obj["trajectory"]
    points = points[:5]

    first_point = points[0]
    last_point = points[-1]
    x1, y1 = get_coordinates(first_point)
    x2, y2 = get_coordinates(last_point)

    distance = math.hypot(float(x2) - float(x1), float(y2) - float(y1))
    if distance < 10.0:
        point = Point(x2, y2)
        return find_nearest_start_area(point, starts)

    length = 0
    sum_angles = 0
    sum_distances = 0
    final_distances = list()
    """for i in range(4):
        x1, y1 = get_coordinates(points[i])
        x2, y2 = get_coordinates(points[i + 1])

        distance = math.hypot(float(x2) - float(x1), float(y2) - float(y1))
        angle = math.atan2(float(y2) - float(y1), float(x2) - float(x1))
        angle = math.degrees(angle)

        length += 1
        sum_angles += angle
        sum_distances += distance"""

    angle = 0
    angles = list()
    for i in range(4):
        x1, y1 = get_coordinates(points[i])
        x2, y2 = get_coordinates(points[i + 1])

        distance = math.hypot(float(x2) - float(x1), float(y2) - float(y1))
        angle = math.atan2(float(y2) - float(y1), float(x2) - float(x1))
        angle = math.degrees(angle)

        angles.append(angle)

        length += 1
        sum_distances += distance

    for idx in range(len(angles) - 1):
        old_angle = angles[idx]
        new_angle = angles[idx + 1]
        if old_angle < 0:
            old_angle = 360 - abs(old_angle)
        if new_angle < 0:
            new_angle = 360 - abs(new_angle)

        d = new_angle - old_angle
        if d > 180:
            d -= 360
        if d < -180:
            d += 360

        if d > 60 or d < -60:
            point = Point(x2, y2)
            return find_nearest_start_area(point, starts)

    if not angles:
        angle = math.radians(angle)
    else:
        a = b = 0
        for ang in angles:
            ang = math.radians(ang)
            a += cos(ang)
            b += sin(ang)

        angle = math.atan2(b, a)

    angle = math.degrees(angle)
    if angle < 0:
        angle += 180
    else:
        angle -= 180
    angle = math.radians(angle)

    distance = sum_distances / length

    x0, y0 = get_coordinates(points[0])

    x = float(x0) + distance * cos(angle)
    y = float(y0) + distance * sin(angle)

    point = Point(x, y)
    point_list = list()
    point_list.append(x)
    point_list.append(y)

    idx = 0
    while roi.contains(point):
        for start in starts:
            idx += 1
            if start.contains(point):
                break

        idx = 0
        x0, y0 = get_coordinates(point_list)
        x = float(x0) + distance * cos(angle)
        y = float(y0) + distance * sin(angle)
        point = Point(x, y)
        point_list[:] = []
        point_list.append(x)
        point_list.append(y)

    distances = find_nearest_start_area(point, starts)
    for idx in range(len(starts)):
        dist = starts[distances[idx]].exterior.distance(point)
        if dist <= 100:
            final_distances.append(distances[idx])

    if not final_distances:
        return "-"

    return final_distances


def find_nearest_end_area(point, ends):
    distance_vector = list()
    final_distances = list()

    for area in range(0, len(ends)):
        distance = ends[area].exterior.distance(point)
        # if distance <= 100:
        distance_vector.append(distance)

    sorted_distance = sorted(range(len(distance_vector)), key=lambda k: distance_vector[k])
    # return sorted_distance

    for idx in range(len(ends)):
        dist = ends[sorted_distance[idx]].exterior.distance(point)
        if dist <= 100:
            final_distances.append(sorted_distance[idx])

    if not final_distances:
        return "-"

    return final_distances


def find_idx(start, end, dirs):
    idx = 0
    direction = str(str(start) + "-" + str(end))

    for d in dirs:
        idx += 1
        if direction == d:
            return idx

    return 0


def find_direction(points, predicted_length, truck_length, point_types, start, end, directions, ends, dirs, out_list, frame_number, video_id):
    idx = 0
    last_point = points[-1]
    x, y = get_coordinates(last_point)
    point = Point(x, y)
    if isinstance(end, list):
        end = int(end[0]) + 1
        distance = ends[end - 1].exterior.distance(point)
        if distance > 100:
            return directions, out_list

    if isinstance(start, list):
        for i in range(0, len(start)):
            idx = find_idx(start[i] + 1, end, dirs)
            if idx != 0:
                break
    else:
        idx = find_idx(start, end, dirs)

    if idx != 0:
        if predicted_length / len(points) <= 0.75:
            obj_type = find_type(len(points), truck_length, point_types)
            if obj_type == "truck":
                obj_type_id = 2
                count = directions[idx]['truck']
                count += 1
                directions[idx]['truck'] = count

            else:
                obj_type_id = 1
                count = directions[idx]['car']
                count += 1
                directions[idx]['car'] = count

            out_line = '\n' + video_id + ',' + str(frame_number + 1) + ',' + str(idx) + ',' + str(obj_type_id)
            out_list.write(out_line)

    return directions, out_list


def find_type(length, truck_length, types):
    truck = 0
    car = 0

    #if truck_length > length - truck_length:
        #return "truck"

    if len(types) >= 20:
        types = types[-20:]
        for obj_type in types:
            if obj_type == 't':
                truck += 1
            if obj_type == 'c':
                car += 1

        if truck / 20 >= 0.75:
            return "truck"

    truck = 0
    car = 0

    if len(types) >= 5:
        types = types[-5:]
        for obj_type in types:
            if obj_type == 't':
                truck += 1
            if obj_type == 'c':
                car += 1

        if truck >= 5:
            return "truck"
        else:
            return "car"

    return "car"


def find_end_area(point, ends):
    idx = 0
    for end in ends:
        idx += 1
        if end.contains(point):
            return idx

    return "-"


def find_distance(points):
    points = points[-2:]

    x1, y1 = get_coordinates(points[0])
    x2, y2 = get_coordinates(points[1])

    distance = math.hypot(float(x2) - float(x1), float(y2) - float(y1))

    if distance <= 0.0:
        distance = float(3.0)

    return distance


def get_color(color):
    color = color.split('-')
    r = color[0]
    g = color[1]
    b = color[2]

    return r, g, b


def find_angle(points):
    distance = find_distance(points)

    #if distance < 5.0:
     #   return "-"

    points = points[-2:]

    x1, y1 = get_coordinates(points[0])
    x2, y2 = get_coordinates(points[1])

    angle = math.atan2(float(y2) - float(y1), float(x2) - float(x1))
    angle = math.degrees(angle)

    return angle


def get_average(distances):
    sum = 0
    length = 0
    for distance in distances:
        if distance == '' or distance == ' ':
            continue
        if float(distance) < -20.0 or float(distance) > 20.0:
            continue

        length += 1
        sum += float(distance)

    return sum / length


def predict_trajectory_point(obj, ends, roads, roi):
    distance_difference = obj["distance_difference"]
    # angle_difference = obj["angle_difference"]
    points = obj["trajectory"]
    angles = list()
    distance = obj["distance"]
    angle = obj["angle"]
    if len(distance_difference) == 1:
        distance = distance + (float(distance_difference[0]) / 2)

    else:
        if distance_difference[-1] < -10:
            distance = distance + (abs(float(distance_difference[-1])))
            del obj["distance_difference"][-1]
            if len(distance_difference) > 1:
                if distance_difference[-1] > 10:
                    distance = distance - (abs(float(distance_difference[-1])))
                    del obj["distance_difference"][-1]
        elif distance_difference[-1] > 10:
            distance = distance - (abs(float(distance_difference[-1])))
            del obj["distance_difference"][-1]
            if len(distance_difference) > 1:
                if distance_difference[-1] < -10:
                    distance = distance + (abs(float(distance_difference[-1])))
                    del obj["distance_difference"][-1]

        elif distance_difference[-1] < -5:
            distance = distance + (abs(float(distance_difference[-1])) / 2)

    obj["distance"] = distance

    last_point = points[-1]
    x0, y0 = get_coordinates(last_point)

    if len(obj["road"]) != 1:
        if len(points) >= 5:
            points = points[-5:]
            for i in range(4):
                x1, y1 = get_coordinates(points[i])
                x2, y2 = get_coordinates(points[i + 1])

                angle = math.atan2(float(y2) - float(y1), float(x2) - float(x1))
                angle = math.degrees(angle)

                angles.append(angle)

        else:
            if isinstance(angle, str):
                angle_points = points[-2:]

                x1, y1 = get_coordinates(angle_points[0])
                x2, y2 = get_coordinates(angle_points[1])

                angle = math.atan2(float(y2) - float(y1), float(x2) - float(x1))
                angle = math.degrees(angle)

        if not angles:
            angle = math.radians(angle)
        else:
            a = b = 0
            for ang in angles:
                ang = math.radians(ang)
                a += cos(ang)
                b += sin(ang)

            angle = math.atan2(b, a)

        if obj["included"] != "-" and obj["included_length"] < 5:
            angle = obj["angle"]
            angle = math.radians(angle)

    else:
        #chcem najst koniec, ktory patri ku danej ceste
        road_id = int(obj["road"][0]) - 1
        road = roads[road_id]
        intersections = list()

        for end in ends:
            #if road.intersects(end):
                intersection = end.intersection(road)
                percentage = intersection.area / end.area * 100
                intersections.append(percentage)

        idx = intersections.index(max(intersections))
        end = ends[idx]

        end_center_point = list(end.centroid.coords)
        center_x = end_center_point[0][0]
        center_y = end_center_point[0][1]

        dist = math.hypot(float(x0) - float(center_x), float(y0) - float(center_y))

        # v pripade ze je vzialenost od ciela vacsia ako 300
        if dist > 200:
            # skontrolujem uhol (ked rozdiel bude vacsi jak +-60 tak budem predpovedat v danom smere)
            ang = math.atan2(float(center_y) - float(y0), float(center_x) - float(x0))
            ang = math.degrees(ang)
            if ang < 0:
                ang = 360 - abs(ang)
            if angle < 0:
                angle = 360 - abs(angle)

            if not (angle - 30 < ang < angle + 30 or (ang < angle - 330) or (ang > angle + 330)):
                if len(points) >= 5:
                    points = points[-5:]
                    for i in range(4):
                        x1, y1 = get_coordinates(points[i])
                        x2, y2 = get_coordinates(points[i + 1])

                        angle = math.atan2(float(y2) - float(y1), float(x2) - float(x1))
                        angle = math.degrees(angle)

                        angles.append(angle)

                else:
                    if isinstance(angle, str):
                        angle_points = points[-2:]

                        x1, y1 = get_coordinates(angle_points[0])
                        x2, y2 = get_coordinates(angle_points[1])

                        angle = math.atan2(float(y2) - float(y1), float(x2) - float(x1))
                        angle = math.degrees(angle)

                if not angles:
                    angle = math.radians(angle)
                else:
                    a = b = 0
                    for ang in angles:
                        ang = math.radians(ang)
                        a += cos(ang)
                        b += sin(ang)

                    angle = math.atan2(b, a)

            else:
                angle = math.atan2(float(center_y) - float(y0), float(center_x) - float(x0))

        else:
            if distance > 5:

                if len(points) >= 5:
                    points = points[-5:]
                    for i in range(4):
                        x1, y1 = get_coordinates(points[i])
                        x2, y2 = get_coordinates(points[i + 1])

                        angle = math.atan2(float(y2) - float(y1), float(x2) - float(x1))
                        angle = math.degrees(angle)

                        angles.append(angle)

                else:
                    if isinstance(angle, str):
                        angle_points = points[-2:]

                        x1, y1 = get_coordinates(angle_points[0])
                        x2, y2 = get_coordinates(angle_points[1])

                        angle = math.atan2(float(y2) - float(y1), float(x2) - float(x1))
                        angle = math.degrees(angle)

                if not angles:
                    angle = math.radians(angle)
                else:
                    a = b = 0
                    for ang in angles:
                        ang = math.radians(ang)
                        a += cos(ang)
                        b += sin(ang)

                    angle = math.atan2(b, a)

                point = Point(x0, y0)
                point_list = list()
                point_list.append(x0)
                point_list.append(y0)
                found = False
                """p1, p2 = nearest_points(end, point)
    
                angle = math.atan2(float(p1.y) - float(y0), float(p1.x) - float(x0))"""

                while roi.contains(point):
                    if end.contains(point):
                        found = True
                        break

                    #angle = math.radians(angle)
                    xx, yy = get_coordinates(point_list)
                    x = float(xx) + distance * cos(angle)
                    y = float(yy) + distance * sin(angle)
                    point = Point(x, y)
                    point_list[:] = []
                    point_list.append(x)
                    point_list.append(y)

                if not found:
                    angle = math.atan2(float(center_y) - float(y0), float(center_x) - float(x0))
            else:
                angle = math.atan2(float(center_y) - float(y0), float(center_x) - float(x0))

    # angle = math.radians(angle)
    x = float(x0) + distance * cos(angle)
    y = float(y0) + distance * sin(angle)

    predicted_point = list()
    predicted_point.append(x)
    predicted_point.append(y)

    return obj, predicted_point


def delete_last_difference(distance_difference):
    del distance_difference[-1]

    return distance_difference


def get_last_difference(distance_difference):
    return float(distance_difference[-1])


def get_last_trajectory_point(points):
    point = points[-1]
    x = point[0]
    y = point[1]

    return float(x), float(y)


def find_object(points, angle, objects, object_id):
    circle_x, circle_y = get_last_trajectory_point(points)
    rad = 150
    obj_idx = "-"

    for idx in objects:
        if (objects[idx]["length"] == 2 or objects[idx]["length"] == 3) and objects[idx]["age"] <= 3 and not \
                objects[idx]["finished"] and not objects[idx]["state"] == "assigned":
            x1, y1 = get_coordinates(objects[idx]["trajectory"][0])
            x2, y2 = get_coordinates(objects[idx]["trajectory"][-1])
            x = (x1 + x2) / 2
            y = (y1 + y2) / 2
            ob_angle = objects[idx]["angle"]
            if not isinstance(ob_angle, str):
                if ob_angle < 0 and not isinstance(ob_angle, str):
                    ob_angle = 360 - abs(ob_angle)
            if not isinstance(angle, str):
                if angle < 0:
                    angle = 360 - abs(angle)

            if not isinstance(ob_angle, str) and not isinstance(angle, str):
                if (x - circle_x) * (x - circle_x) + (y - circle_y) * (y - circle_y) <= rad * rad:
                    if (angle - 45 < ob_angle < angle + 45) or (ob_angle < angle - 270) or (ob_angle > angle + 270):
                        obj_idx = idx
                        break

    if obj_idx != "-":
        if objects[object_id]["type"][-1] == 't':
            obj1_size = objects[object_id]["bbox_size"]
            obj2_size = objects[obj_idx]["bbox_size"]

            if obj2_size < (obj1_size / 3):
                obj_idx = "-"

    return obj_idx


def delete_predicted_points(points, length):
    points = points[:len(points) - length]

    return points


def merge_trajectories(objects, idx1, idx2):
    for point in objects[idx2]["trajectory"]:
        objects[idx1]["trajectory"].append(point)
    objects[idx1]["length"] += objects[idx2]["length"]
    objects[idx2]["state"] = "assigned"
    return objects


def get_properties(file):
    starts = []
    ends = []
    directions = []
    text_coords = []
    roads = []
    start = False
    end = False
    direction = False

    directions_count = {}
    directions_number = 0

    for line in file:
        if line[-1] == "\n":
            line = line[:-1]

        if line == "start":
            start = True
            end = False
            direction = False
        elif line == "end":
            start = False
            end = True
            direction = False
        elif line == "direction":
            start = False
            end = False
            direction = True

        else:
            if start:
                points = line.split(' ')
                point_list = []
                for point in points:
                    x, y = get_coord_from_str(point)
                    p = Point(x, y)
                    point_list.append(p)
                polygon = Polygon([[p.x, p.y] for p in point_list])
                starts.append(polygon)

            elif end:
                points = line.split(' ')
                point_list = []
                for point in points:
                    x, y = get_coord_from_str(point)
                    p = Point(x, y)
                    point_list.append(p)
                polygon = Polygon([[p.x, p.y] for p in point_list])
                ends.append(polygon)

            elif direction:
                ids = line.split(':')
                ids = ids[1].split(' - ')
                dir_and_coor = ids[0]
                points = ids[1]
                dir_and_coor = dir_and_coor.split(' ')
                directions.append(dir_and_coor[0])
                text_coords.append(dir_and_coor[1])
                points = points.split(' ')
                point_list = []
                for point in points:
                    x, y = get_coord_from_str(point)
                    p = Point(x, y)
                    point_list.append(p)
                polygon = Polygon([[p.x, p.y] for p in point_list])
                roads.append(polygon)
                directions_number += 1

    for idx in range(1, directions_number + 1):
        directions_count[idx] = {}
        directions_count[idx]['car'] = 0
        directions_count[idx]['truck'] = 0

    return starts, ends, directions_count, directions, text_coords, roads


def draw_polygon(frame, polygon_points):
    frame = cv2.polylines(frame, [polygon_points], True, (0, 255, 0), 1)
    return frame


def get_roi(roi_file):
    polygon_point = list()
    polygon_points = list()
    point_list = list()
    for line in roi_file:
        if line[-1] == "\n":
            line = line[:-1]
        if line == "":
            continue

        points = line.split(',')
        x = int(points[0])
        y = int(points[1])
        p = Point(x, y)
        polygon_point.append(x)
        polygon_point.append(y)
        polygon_points.append(polygon_point)
        point_list.append(p)

    polygon = Polygon([[p.x, p.y] for p in point_list])
    pts = np.array(polygon_points, np.int32)
    pts = pts.reshape((-1, 1, 2))

    return polygon, pts


def draw_counts(frame, directions, text_coords):
    for i in range(0, len(directions)):
        x, y = get_coord_from_str(text_coords[i])
        cv2.putText(frame, str(i + 1) + "-" + str(directions[i + 1]['car']) + ":" + str(directions[i + 1]['truck']), (x, y), 1, 1.5, (255, 255, 255), 2, cv2.LINE_AA)


def distance_ok(points):
    x1, y1 = get_coordinates(points[0])
    x2, y2 = get_coordinates(points[-1])

    distance = math.hypot(float(x2) - float(x1), float(y2) - float(y1))

    # if (float(first_point) - float(last_point)) > 7.5:
    if distance > 10.0:
        return True

    return False


# Funkcia vypocita rozdielov dvoch uhlov
def calculate_angle_difference(old_angle, new_angle):
    difference = 0
    if (old_angle >= 0 and new_angle >= 0) or (old_angle < 0 and new_angle < 0):
        difference = round(new_angle - old_angle, 2)
    elif old_angle >= 0 and new_angle < 0:
        old_angle = (180 - old_angle) * 2 + old_angle
        new_angle = abs(new_angle)
        difference = round(new_angle - old_angle, 2)
    elif old_angle < 0 and new_angle >= 0:
        old_angle = abs(old_angle)
        new_angle = (180 - new_angle) * 2 + new_angle
        difference = round(new_angle - old_angle, 2)

    return difference


"""Funkcia riesi problem, ze niekedy sa stojace objkety detekuju ako pohybujuce sa a predikuje sa ich nasledny pohyb
   Skontroluje poslednych 5 bodov trajektorie, ci sa je posledny bod aspon v urcitej vzdialenosti od prveho (> 10)
   a ci medzi tymi bodmi niesu rozne uhly"""
def check_move(obj):
    points = obj["trajectory"]
    points = points[-5:]

    if len(points) >= 5:
        first_point = points[0]
        last_point = points[-1]
        x1, y1 = get_coordinates(first_point)
        x2, y2 = get_coordinates(last_point)

        distance = math.hypot(float(x2) - float(x1), float(y2) - float(y1))
        if distance < 10.0:
            return False

        angles = list()
        for i in range(4):
            x1, y1 = get_coordinates(points[i])
            x2, y2 = get_coordinates(points[i + 1])

            angle = math.atan2(float(y2) - float(y1), float(x2) - float(x1))
            angle = math.degrees(angle)

            angles.append(angle)

        for idx in range(len(angles) - 1):
            old_angle = angles[idx]
            new_angle = angles[idx + 1]
            if old_angle < 0:
                old_angle = 360 - abs(old_angle)
            if new_angle < 0:
                new_angle = 360 - abs(new_angle)

            d = new_angle - old_angle
            if d > 180:
                d -= 360
            if d < -180:
                d += 360

            if d > 60 or d < -60:
                return False

    return True


""" Funkcia riesi problem, ze niekedy sa objekt s danym ID objavi tam, kde nema byt
    Otestuje sa, ci sa dalsi bod nenachadza prilis daleko (distance > 100) od posledneho bodu a ci sa nenachadza
    v netradicnom uhle (angle difference > 60)
    Vrati True ak vyhovuje, False ak nevyhovuje"""
def check_point(points, point):
    if len(points) == 1:
        return True

    last_x, last_y = get_coordinates(points[-1])
    new_x, new_y = get_coordinates(point)

    distance = math.hypot(float(new_x) - float(last_x), float(new_y) - float(last_y))

    first_x, first_y = get_coordinates(points[-2])
    first_angle = math.atan2(float(last_y) - float(first_y), float(last_x) - float(first_x))
    first_angle = math.degrees(first_angle)

    second_angle = math.atan2(float(new_y) - float(last_y), float(new_x) - float(last_x))
    second_angle = math.degrees(second_angle)

    if first_angle < 0:
        first_angle = 360 - abs(first_angle)
    if second_angle < 0:
        second_angle = 360 - abs(second_angle)

    d = second_angle - first_angle
    if d > 180:
        d -= 360
    if d < -180:
        d += 360

    if distance > 100 and (d > 60 or d < -60):
        return False

    return True


# Funckia vrati nahodnu farbu (r, g, b)
def make_color():
    r = str(random.randint(0, 255))
    g = str(random.randint(0, 255))
    b = str(random.randint(0, 255))

    return r, g, b


# Funkcia vykresli bounding box a index daneho objektu
def draw_bounding_box(frame, bbox, obj_type, idx):
    if obj_type == "car":
        cv2.rectangle(frame, (int(bbox[0]), int(bbox[1])), (int(bbox[2]), int(bbox[3])), (255, 255, 255),
                      2)  # Nakresli bounding box
        cv2.putText(frame, str(idx), (int(bbox[0]), int(bbox[1])), 0, 5e-3 * 200, (0, 255, 0),
                    2)  # Nakresli id sledovaneho objektu
    if obj_type == "truck":
        cv2.rectangle(frame, (int(bbox[0]), int(bbox[1])), (int(bbox[2]), int(bbox[3])), (0, 0, 255),
                      2)  # Nakresli bounding box
        cv2.putText(frame, str(idx), (int(bbox[0]), int(bbox[1])), 0, 5e-3 * 200, (0, 255, 0),
                    2)  # Nakresli id sledovaneho objektu

    return frame


# Funckia nakresli trajektorie jednotlivych objektov vratane sipky vyznacujucej smer
def draw_trajectory(overlay, points, roi, polygon_points, color):
    index = 0
    r, g, b = get_color(color)
    x, y = get_coordinates(points[-1])
    pt = Point(x, y)
    if not roi.contains(pt):
        del points[-1]

    first_access = True
    for point in points:
        x, y = get_coordinates(point)
        pt = Point(x, y)
        if not roi.contains(pt):
            return overlay

        if first_access:
            previous_point = points[0]
            previous_pointX, previous_pointY = get_coordinates(previous_point)
            first_access = False

        overlay = draw_polygon(overlay, polygon_points)

        cv2.line(overlay, (int(float(previous_pointX)), int(float(previous_pointY))),
                 (int(float(x)), int(float(y))),
                 (int(r), int(g), int(b)), 2)

        index += 1

        if index == len(points) and len(points) > 6:
            arrow_point = points[index - 5]
            arrow_pointX, arrow_pointY = get_coordinates(arrow_point)

            angle = math.atan2(int(float(arrow_pointY)) - int(float(y)),
                               int(float(arrow_pointX)) - int(float(x)))
            CV_PI = 3.1415926535897932384626433832795
            degrees_angle = angle * 180 / CV_PI

            sipkaX = round(int(float(x)) + 10 * math.cos((degrees_angle + 30) * CV_PI / 180))
            sipkaY = round(int(float(y)) + 10 * math.sin((degrees_angle + 30) * CV_PI / 180))

            sipkaX2 = round(int(float(x)) + 10 * math.cos((degrees_angle - 30) * CV_PI / 180))
            sipkaY2 = round(int(float(y)) + 10 * math.sin((degrees_angle - 30) * CV_PI / 180))

            cv2.line(overlay, (int(float(sipkaX)), int(float(sipkaY))), (int(float(x)), int(float(y))),
                     (int(r), int(g), int(b)), 2)
            cv2.line(overlay, (int(float(sipkaX2)), int(float(sipkaY2))),
                     (int(float(x)), int(float(y))),
                     (int(r), int(g), int(b)), 2)

        previous_pointX = x
        previous_pointY = y

    return overlay


# Funkcia inicializuje novy objekt
def initialize_object(r, g, b, trajectory_point, obj_type, road_id):
    obj = {}
    obj["color"] = r + '-' + g + '-' + b
    obj["trajectory"] = list()
    obj["trajectory"].append(trajectory_point)
    obj["length"] = 0
    obj["TTL"] = 50
    obj["startID"] = 0
    obj["endID"] = "-"
    obj["finished"] = False
    obj["distance"] = 0
    obj["angle"] = 0
    obj["distance_difference"] = list()
    obj["angle_difference"] = list()
    obj["state"] = "detected"
    obj["predicted_length"] = 0
    obj["include"] = "-"
    obj["included"] = "-"
    obj["included_length"] = 0
    obj["age"] = 0
    obj["type"] = list()
    obj["truck_length"] = 0
    obj["bbox_size"] = 0
    obj["road"] = road_id

    if obj_type == "truck":
        obj["truck_length"] += 1
        obj["type"].append('t')

    else:
        obj["type"].append('c')

    obj["duplicate_id"] = "-"

    return obj


def handle_detected(objects, object_id):
    if objects[object_id]["length"] == 1:
        return objects, False
    dist = find_distance(objects[object_id]["trajectory"])
    length = objects[object_id]["length"]

    if not check_move(objects[object_id]):
        return objects, False
    if length < 3:
        return objects, False
    elif length > 4 and distance_ok(objects[object_id]["trajectory"]):
        objects[object_id]["state"] = "predicted"
    elif dist > 7.5:
        objects[object_id]["state"] = "predicted"
    else:
        return objects, False

    if objects[object_id]["length"] > 3:
        last_difference = get_last_difference(objects[object_id]["distance_difference"])
        objects[object_id]["distance"] = objects[object_id]["distance"] - last_difference
        objects[object_id]["distance_difference"] = delete_last_difference(
                objects[object_id]["distance_difference"])

    return objects, True


def handle_redetected(objects, object_id):
    new_x, new_y = get_last_trajectory_point(
        objects[objects[object_id]["include"]]["trajectory"])
    x, y = get_last_trajectory_point(objects[object_id]["trajectory"])
    if x - 0.1 < new_x < x + 0.1 and y - 0.1 < new_y < y + 0.1:
        last_difference = get_last_difference(objects[object_id]["distance_difference"])
        objects[object_id]["distance"] = objects[object_id]["distance"] - last_difference
        objects[object_id]["distance_difference"] = delete_last_difference(
            objects[object_id]["distance_difference"])
        objects[object_id]["state"] = "predicted"
        objects[object_id]["included"] = objects[object_id]["include"]

    else:
        new_point = list()
        new_point.append(new_x)
        new_point.append(new_y)
        objects[object_id]["trajectory"].append(new_point)
        objects[object_id]["type"].append(objects[objects[object_id]["include"]]["type"][-1])
        road_id = minimalize_roads_possibilities(objects[object_id]["road"], objects[objects[object_id]["include"]]["road"])
        objects[object_id]["road_id"] = road_id
        objects[object_id]["length"] += 1
        objects[object_id]["included_length"] += 1

    return objects


def handle_predicted(objects, object_id, ends, roads, roi):
    include = find_object(objects[object_id]["trajectory"], objects[object_id]["angle"], objects, object_id)

    if include == object_id or include == objects[object_id]["include"]:
        objects[object_id]["include"] = "-"
    else:
        objects[object_id]["include"] = include

    if objects[object_id]["include"] != "-":
        objects[object_id]["trajectory"] = delete_predicted_points(
            objects[object_id]["trajectory"], objects[object_id]["predicted_length"])
        objects[object_id]["length"] -= objects[object_id]["predicted_length"]
        objects = merge_trajectories(objects, object_id, objects[object_id]["include"])
        objects[object_id]["predicted_length"] = 0
        objects[object_id]["state"] = "redetected"
        objects[include]["include"] = object_id
    else:
        objects[object_id], predicted_point = predict_trajectory_point(objects[object_id], ends, roads, roi)
        objects[object_id]["trajectory"].append(predicted_point)
        objects[object_id]["predicted_length"] += 1
        objects[object_id]["length"] += 1

    return objects


def find_distance_and_angle_difference(objects, object_id):
    if objects[object_id]["included"] != "-" and objects[object_id]["included_length"] < 3:
        objects[object_id]["included_length"] = 0
        return objects

    old_distance = objects[object_id]["distance"]
    objects[object_id]["distance"] = find_distance(objects[object_id]["trajectory"])
    new_distance = objects[object_id]["distance"]
    distance_difference = round(new_distance - old_distance, 2)
    objects[object_id]["distance_difference"].append(distance_difference)

    old_angle = objects[object_id]["angle"]
    objects[object_id]["angle"] = find_angle(objects[object_id]["trajectory"])
    new_angle = objects[object_id]["angle"]
    if not isinstance(old_angle, str) and not isinstance(new_angle, str):
        # angle_difference = round(new_angle - old_angle, 2)
        angle_difference = calculate_angle_difference(old_angle, new_angle)
        objects[object_id]["angle_difference"].append(angle_difference)
    else:
        objects[object_id]["angle_difference"].append("-")

    return objects


def calculate_iou(track_bbox, det_bbox):
    xA = max(int(track_bbox[0]), int(det_bbox[0]))
    yA = max(int(track_bbox[1]), int(det_bbox[1]))
    xB = min(int(track_bbox[2]), int(det_bbox[2]))
    yB = min(int(track_bbox[3]), int(det_bbox[3]))
    # compute the area of intersection rectangle
    interArea = max(0, xB - xA + 1) * max(0, yB - yA + 1)
    # compute the area of both the prediction and ground-truth
    # rectangles
    boxAArea = (int(track_bbox[2]) - int(track_bbox[0]) + 1) * (int(track_bbox[3]) - int(track_bbox[1]) + 1)
    boxBArea = (int(det_bbox[2]) - int(det_bbox[0]) + 1) * (int(det_bbox[3]) - int(det_bbox[1]) + 1)
    # compute the intersection over union by taking the intersection
    # area and dividing it by the sum of prediction + ground-truth
    # areas - the interesection area
    iou = interArea / float(boxAArea + boxBArea - interArea)

    return iou


def check_bbox(bbox, average_bbox_size, obj_type):
    width = int(bbox[2]) - int(bbox[0])
    height = int(bbox[3]) - int(bbox[1])
    if height > 1.5 * width:
        return False

    size = width * height

    if average_bbox_size == 0:
        return True

    if size > average_bbox_size * 5 and obj_type != "truck":
        return False

    return True


def get_bbox_size(bbox):
    width = int(bbox[2]) - int(bbox[0])
    height = int(bbox[3]) - int(bbox[1])

    size = width * height

    return size


def delete_last_n_points(points, length):
    for i in range(length):
        del points[-1]

    return points


def find_road(roads, point):
    idx = 0
    road_id = list()
    for road in roads:
        idx += 1
        if road.contains(point):
            road_id.append(idx)

    """if not road_id:
        return road_id, False

    elif len(road_id) == 1:
        return road_id, True

    else:
        return road_id, True"""

    return road_id


def minimalize_roads_possibilities(current_road, previous_road):
    # Aj minula aj sucasna cesta je iba jedna
    if len(current_road) == 1 and len(previous_road) == 1:
        if current_road[0] == previous_road[0]:
            return current_road
        else:
            return []

    # Sucasnych je
    else:
        final_road = set(current_road) & set(previous_road)
        final_road = list(final_road)
        return final_road

def main(yolo):
    # Definition of the parameters
    max_cosine_distance = 0.3
    nn_budget = None
    nms_max_overlap = 1.0

    frame_number = 0
    first_frame = True
    average_bbox_size = 0

    objects = {}
    possible_objects = {}
    ious = list()

    frame_index = -1
    duplicate_id = -1
    file = open('cam_props/cam_19_prop.txt', 'r')
    roi_file = open('dataset/ROIs/cam_19.txt', 'r')
    out_list = open('outlist/cam_19_dawna_out.txt', 'w+')
    out_list.write("video_clip_id, frame_id, movement_id, vehicle_class_id")
    video_id = "122"

    # deep_sort
    model_filename = 'model_data/mars-small128.pb'
    encoder = gdet.create_box_encoder(model_filename, batch_size=1)

    metric = nn_matching.NearestNeighborDistanceMetric("cosine", max_cosine_distance, nn_budget)
    tracker = Tracker(metric)

    writeVideo_flag = True

    video_capture = cv2.VideoCapture("dataset/Dataset_A/cam_19.mp4")
    #video_capture = cv2.VideoCapture("cam_1_cut.mp4")

    if writeVideo_flag:
        # Define the codec and create VideoWriter object
        w = int(video_capture.get(3))
        h = int(video_capture.get(4))
        fourcc = cv2.VideoWriter_fourcc(*'MJPG')
        out = cv2.VideoWriter('cam_19.avi', fourcc, 15, (w, h))
        list_file = open('detection.txt', 'w')

    roi, polygon_points = get_roi(roi_file)
    starts, ends, directions, dirs, text_coords, roads = get_properties(file)

    fps = 0.0
    while True:
        ret, frame = video_capture.read()  # frame shape 640*480*3
        if not ret:
            break
        t1 = time.time()

        if first_frame:
            first_frame = False
            analyze_frame = frame.copy()

        # image = Image.fromarray(frame)
        image = Image.fromarray(frame[..., ::-1])  # bgr to rgb
        boxs, object_types = yolo.detect_image(image)
        features = encoder(frame, boxs)

        # score to 1.0 here).
        detections = [Detection(bbox, 1.0, feature) for bbox, feature in zip(boxs, features)]

        # Run non-maxima suppression.
        boxes = np.array([d.tlwh for d in detections])
        scores = np.array([d.confidence for d in detections])
        indices = preprocessing.non_max_suppression(boxes, nms_max_overlap, scores)
        detections = [detections[i] for i in indices]
        object_types = [object_types[i] for i in indices]

        # Call the tracker
        frame_number += 1

        tracker.predict()
        tracker.update(detections, object_types)

        for track in tracker.tracks:
            ious[:] = []
            trajectory_point = list()
            if not track.is_confirmed() or track.time_since_update > 1:
                continue

            track_bbox = track.to_tlbr()


            """for det in detections:
                det_bbox = det.to_tlbr()
                iou = calculate_iou(track_bbox, det_bbox)
                if iou > 0.75:
                    ious.append(det_bbox)"""

            if len(ious) == 1:
                det_bbox = ious[0]
                x = (int(det_bbox[0]) + int(det_bbox[2])) / 2  # x-ova suradnica stredu bounding boxu
                y = (int(det_bbox[1]) + int(det_bbox[3])) / 2  # y-ova suradnica stredu bounding boxu
            else:
                x = (int(track_bbox[0]) + int(track_bbox[2])) / 2  # x-ova suradnica stredu bounding boxu
                y = (int(track_bbox[1]) + int(track_bbox[3])) / 2  # y-ova suradnica stredu bounding boxu

            trajectory_point.append(int(x))
            trajectory_point.append(int(y))

            point = Point(int(x), int(y))
            if not roi.contains(point):
                continue

            frame = draw_bounding_box(frame, track_bbox, track.object_type, track.track_id)

            """if str(track.track_id) == "70":
                draw_analyze(analyze_frame)

            if not check_bbox(track_bbox, average_bbox_size, track.object_type):
                continue"""

            bbox_size = get_bbox_size(track_bbox)
            """if average_bbox_size == 0:
                average_bbox_size = bbox_size
            else:
                average_bbox_size = (average_bbox_size + bbox_size) / 2"""

            if frame_number >= 73:
                draw_analyze(frame)

            road_id = find_road(roads, point)
            #road_id, ok = find_road(roads, point)
            #if not ok:
                #continue

            # Objekt sa este nenachadza v poli objektov - inicializacia objektu
            if str(track.track_id) not in objects:
                r, g, b = make_color()
                objects[str(track.track_id)] = initialize_object(r, g, b, trajectory_point, track.object_type, road_id)

            # Objekt sa uz nachadza v poli
            else:
                if check_point(objects[str(track.track_id)]["trajectory"], trajectory_point):
                    if objects[str(track.track_id)]["predicted_length"] > 0:
                        objects[str(track.track_id)]["trajectory"] = delete_last_n_points(objects[str(track.track_id)]["trajectory"], objects[str(track.track_id)]["predicted_length"])
                        objects[str(track.track_id)]["length"] -= objects[str(track.track_id)]["predicted_length"]
                        objects[str(track.track_id)]["predicted_length"] = 0
                    objects[str(track.track_id)]["trajectory"].append(trajectory_point)
                    road_id = minimalize_roads_possibilities(road_id, objects[str(track.track_id)]["road"])
                    objects[str(track.track_id)]["road"] = road_id
                    objects[str(track.track_id)]["bbox_size"] = bbox_size
                    # objects[str(track.track_id)]["age"] += 1
                    if objects[str(track.track_id)]["state"] == "predicted":
                        objects[str(track.track_id)]["state"] = "detected"
                    if objects[str(track.track_id)]["state"] == "assigned" and objects[str(track.track_id)]["include"] != "-":
                        objects[objects[str(track.track_id)]["include"]]["state"] = "redetected"
                        objects[objects[str(track.track_id)]["include"]]["include"] = str(track.track_id)

                else:
                    if objects[str(track.track_id)]["duplicate_id"] == "-":
                        r, g, b = make_color()
                        objects[str(track.track_id)]["duplicate_id"] = duplicate_id
                        objects[str(objects[str(track.track_id)]["duplicate_id"])] = initialize_object(r, g, b, trajectory_point, track.object_type, road_id)
                        duplicate_id -= 1
                    else:
                        #if check_point(objects[str(objects[str(track.track_id)]["duplicate_id"])]["trajectory"], trajectory_point):
                        objects[str(objects[str(track.track_id)]["duplicate_id"])]["trajectory"].append(trajectory_point)
                        """else:
                            r, g, b = make_color()
                            objects[str(track.track_id)]["duplicate_id"] = duplicate_id
                            objects[str(duplicate_id)] = initialize_object(r, g, b, trajectory_point, track.object_type)
                            duplicate_id -= 1"""

                if track.object_type == "truck":
                    objects[str(track.track_id)]["truck_length"] += 1
                    objects[str(track.track_id)]["type"].append('t')
                else:
                    objects[str(track.track_id)]["type"].append('c')

        for det in detections:
            bbox = det.to_tlbr()
            cv2.rectangle(frame, (int(bbox[0]), int(bbox[1])), (int(bbox[2]), int(bbox[3])), (255, 0, 0), 2)

        # Nakreslia sa jednotlive pocty prejdenych vozidiel
        draw_counts(frame, directions, text_coords)
        overlay = frame.copy()

        if len(objects) != 0:
            for object_id in objects:  # Prechadzanie kazdeho objektu v trajektoriach
                #if (object_id == "6" or object_id == "8") and frame_number > 80:
                #if (object_id == "24" or object_id == "12") and frame_number > 96:
                if object_id == "9":
                    draw_analyze(frame)

                points = objects[object_id]["trajectory"]

                if not objects[object_id]["finished"]:
                    objects[object_id]["age"] += 1
                    objects[object_id]["TTL"] = 100

                    if objects[object_id]["state"] == "assigned":
                        continue

                    #print(object_id)

                    # Objekt bol detekovany
                    if len(points) > objects[object_id]["length"]:
                        objects[object_id]["length"] += 1
                        objects[object_id]["TTL"] = 100

                    # Objekt uz nebol detekovany
                    else:
                        # Objekt je v stave detected (ale uz nebol detekovany)
                        if objects[object_id]["state"] == "detected":
                            objects, ok = handle_detected(objects, object_id)
                            if not ok:
                                continue

                        # Objekt je v stave redetected
                        if objects[object_id]["state"] == "redetected":
                            objects = handle_redetected(objects, object_id)

                        # Object je v stave predicted
                        if objects[object_id]["state"] == "predicted":
                            objects = handle_predicted(objects, object_id, ends, roads, roi)

                    if objects[object_id]["length"] > 1:
                        if objects[object_id]["state"] == "redetected":
                            old_distance = objects[object_id]["distance"]
                            new_distance = find_distance(objects[object_id]["trajectory"])
                            distance_difference = round(new_distance - old_distance, 2)
                            objects[object_id]["distance"] = new_distance
                            objects[object_id]["distance_difference"].append(distance_difference)

                        else:
                            objects = find_distance_and_angle_difference(objects, object_id)

                    x, y = get_last_trajectory_point(objects[object_id]["trajectory"])
                    point = Point(x, y)

                    # Start objektu este nie je najdeny (pre kazdy objekt iba raz)
                    if objects[object_id]["startID"] == 0:
                        objects[object_id]["startID"] = find_start_area(point, starts)

                    # Koniec objektu estenie je najdeny
                    if objects[object_id]["endID"] == "-":
                        objects[object_id]["endID"] = find_end_area(point, ends)

                    # Zaciatok aj koniec objektu uz su najdene
                    if objects[object_id]["startID"] != "-" and objects[object_id]["endID"] != "-":
                        directions, out_list = find_direction(objects[object_id]["trajectory"],
                                                              objects[object_id]["predicted_length"],
                                                              objects[object_id]["truck_length"],
                                                              objects[object_id]["type"],
                                                              objects[object_id]["startID"],
                                                              objects[object_id]["endID"],
                                                              directions, ends, dirs, out_list, frame_number, video_id)
                        objects[object_id]["finished"] = True
                        if objects[object_id]["include"] != "-":
                            objects[objects[object_id]["include"]]["finished"] = True
                            objects[objects[object_id]["include"]]["state"] = "assigned"

                    # Koniec je najdeny ale zaciatok nie
                    if objects[object_id]["startID"] == "-" and objects[object_id]["endID"] != "-":
                        # objects[object_id]["startID"] = find_nearest_start_area(points[0], starts)
                        if objects[object_id]["length"] <= 4:
                            objects[object_id]["finished"] = True
                            objects[object_id]["TTL"] = 0
                            break
                        objects[object_id]["startID"] = find_start(objects[object_id]["trajectory"], starts, roi)
                        if objects[object_id]["startID"] == "-":
                            objects[object_id]["finished"] = True
                            objects[object_id]["TTL"] = 0
                            break
                        directions, out_list = find_direction(objects[object_id]["trajectory"],
                                                              objects[object_id]["predicted_length"],
                                                              objects[object_id]["truck_length"],
                                                              objects[object_id]["type"],
                                                              objects[object_id]["startID"],
                                                              objects[object_id]["endID"],
                                                              directions, ends, dirs, out_list, frame_number, video_id)
                        objects[object_id]["finished"] = True
                        if objects[object_id]["include"] != "-":
                            objects[objects[object_id]["include"]]["finished"] = True
                            objects[objects[object_id]["include"]]["state"] = "assigned"

                    # Bod trajektorie sa uz nenachadza v ROI ale koniec este neni najdeny
                    if not roi.contains(point) and objects[object_id]["endID"] == "-":
                        objects[object_id]["endID"] = find_nearest_end_area(point, ends)
                        if objects[object_id]["endID"] == "-":
                            objects[object_id]["finished"] = True
                            objects[object_id]["TTL"] = 0

                        if objects[object_id]["startID"] == "-":
                            # objects[object_id]["startID"] = find_nearest_start_area(points[0], starts)
                            if objects[object_id]["length"] <= 4:
                                objects[object_id]["finished"] = True
                                objects[object_id]["TTL"] = 0
                                break
                            objects[object_id]["startID"] = find_start(objects[object_id]["trajectory"], starts, roi)
                            if objects[object_id]["startID"] == "-":
                                objects[object_id]["finished"] = True
                                objects[object_id]["TTL"] = 0
                                break
                        directions, out_list = find_direction(objects[object_id]["trajectory"],
                                                              objects[object_id]["predicted_length"],
                                                              objects[object_id]["truck_length"],
                                                              objects[object_id]["type"],
                                                              objects[object_id]["startID"],
                                                              objects[object_id]["endID"],
                                                              directions, ends, dirs, out_list, frame_number, video_id)
                        objects[object_id]["finished"] = True
                        if objects[object_id]["include"] != "-":
                            objects[objects[object_id]["include"]]["finished"] = True
                            objects[objects[object_id]["include"]]["state"] = "assigned"

                # Objekt nie je v stave "finished" - znizi sa TTL
                else:
                    objects[object_id]["TTL"] -= 1

                # Ked je objekt priradeny inemu objektu, nevykresli sa jeho trajektoria
                if objects[object_id]["state"] == "assigned":
                    continue

                # V pripade, ze je TTL nenulove, vykreslia sa trajektoria
                if objects[object_id]["TTL"] > 0:
                    overlay = draw_trajectory(overlay, objects[object_id]["trajectory"], roi, polygon_points, objects[object_id]["color"])

        cv2.addWeighted(overlay, 0.75, frame, 1 - 0.75, 0, frame)
        cv2.imshow('', frame)

        if writeVideo_flag:
            # save a frame
            out.write(frame)
            frame_index = frame_index + 1
            list_file.write(str(frame_index) + ' ')
            if len(boxs) != 0:
                for i in range(0, len(boxs)):
                    list_file.write(
                        str(boxs[i][0]) + ' ' + str(boxs[i][1]) + ' ' + str(boxs[i][2]) + ' ' + str(boxs[i][3]) + ' ')
            list_file.write('\n')

        fps = (fps + (1. / (time.time() - t1))) / 2
        print("fps= %f" % (fps))
        print("frame number= %d" % frame_number)
        # print(trajectories)

        # Press Q to stop!
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

        # Na debug
        if cv2.waitKey(1) & 0xFF == ord('z'):
            draw_analyze(analyze_frame)

    #draw_analyze(analyze_frame)

    if writeVideo_flag:
        out.release()
        list_file.close()
    cv2.destroyAllWindows()
    video_capture.release()
    out_list.close()


if __name__ == '__main__':
    main(YOLO())
